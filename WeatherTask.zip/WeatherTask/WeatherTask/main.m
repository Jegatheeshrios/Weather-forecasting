//
//  main.m
//  WeatherTask
//
//  Created by Kandavel on 14/12/1937 SAKA.
//  Copyright © 1937 SAKA J. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
