//
//  ViewController.h
//  WeatherTask
//
//  Created by Kandavel on 14/12/1937 SAKA.
//  Copyright © 1937 SAKA J. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SViewController.h"
#import "Reachability.h"

@interface ViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>
{
    IBOutlet UITextField *maintext;
    IBOutlet UITableView *maintableview;
    NSArray *textarr;
    NSMutableArray *mtextarr;
    UIAlertView *textalert,*cellalert,*netalert;;
    Reachability *reachclass;
}
-(IBAction)Submitaction:(id)sender;



@end

