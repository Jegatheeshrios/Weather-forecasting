//
//  SViewController.m
//  WeatherTask
//
//  Created by Kandavel on 15/12/1937 SAKA.
//  Copyright (c) 1937 SAKA J. All rights reserved.
//

#import "SViewController.h"


@interface SViewController ()

@end

@implementation SViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
      [super viewDidLoad];
    // Do any additional setup after loading the view.
}
-(void)viewWillAppear:(BOOL)animated
{
    [self.view setBackgroundColor:[UIColor colorWithRed:150.0f/255.0f
                                                  green:142.0f/255.0f
                                                   blue:121.0f/255.0f
                                                  alpha:1.0f]];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0),^{
        xAxis=10;
        mainstr=[NSString stringWithFormat:@"http://api.openweathermap.org/data/2.5/forecast/daily?q=%@&cnt=14&APPID=9305c804f0a08b11207e6b25cf1ee59a",_citystr];
        mainurlstr=[NSURL URLWithString:mainstr];
        mrequest=[NSMutableURLRequest requestWithURL:mainurlstr];
        [mrequest setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        [mrequest setValue:@"application/json" forHTTPHeaderField:@"Accept"];
        [mrequest setValue:[NSString stringWithFormat:@"%lu",[mainstr length]] forHTTPHeaderField:@"Content-Lenght"];
        [mrequest setHTTPMethod:@"POST"];
        [mrequest setHTTPBody:[mainstr dataUsingEncoding:NSUTF8StringEncoding]];
        NSURLResponse *resp=nil;
        NSError *err1=nil;
        maindata=[NSURLConnection sendSynchronousRequest:mrequest returningResponse:&resp error:&err1];
        maindict=[NSJSONSerialization JSONObjectWithData:maindata options:kNilOptions error:nil];
        cityname=[[maindict objectForKey:@"city"]objectForKey:@"name"];
        counname=[[maindict objectForKey:@"city"]objectForKey:@"country"];
        mainlistarr=[maindict objectForKey:@"list"];
        dispatch_async(dispatch_get_main_queue(), ^{
            _scityname.text=[[cityname stringByAppendingString:@" "]stringByAppendingString:counname];
            for (int i=0; i<[mainlistarr count]; i++)
            {
                subview1=[[UIView alloc]initWithFrame:CGRectMake(sview.frame.origin.x+xAxis, sview.frame.origin.y-80,sview.frame.size.width-40,sview.frame.size.height-80
                                                                 )];
                templbl=[[UILabel alloc]initWithFrame:CGRectMake(90,40,130, 25)];
                [templbl setText:@"Temp Min/Max"];
                datelb=[[UILabel alloc]initWithFrame:CGRectMake(15, 16, 130, 21)];
                subimgv=[[UIImageView alloc]initWithFrame:CGRectMake(15, 42, 56, 56)];
                tmin=[[UILabel alloc]initWithFrame:CGRectMake(100,72, 53, 25)];
                tmax=[[UILabel alloc]initWithFrame:CGRectMake(160, 72, 53, 25)];
                desclb=[[UILabel alloc]initWithFrame:CGRectMake(15, 100, 220, 25)];
                wspeedlb=[[UILabel alloc]initWithFrame:CGRectMake(15, 130, 95, 25)];
                preslb=[[UILabel alloc]initWithFrame:CGRectMake(115,130,120, 25)];
                [subview1 addSubview:tmin];
                [subview1 addSubview:tmax];
                [subview1 addSubview:wspeedlb];
                [subview1 addSubview:desclb];
                [subview1 addSubview:datelb];
                [subview1 addSubview:subimgv];
                [subview1 addSubview:templbl];
                [subview1 addSubview:preslb];
                [subview1 setBackgroundColor:[UIColor colorWithRed:200.0f/255.0f
                                                             green:222.0f/255.0f
                                                              blue:221.0f/255.0f
                                                             alpha:1.0f]];
                [sview addSubview:subview1];
                xAxis=xAxis+243;
                [self updateInfo:i];
            }
            [sview setContentSize:CGSizeMake(sview.frame.size.width*xAxis, sview.frame.size.height)];
            
        });
    });
}
-(void)updateInfo:(int)position
{
        NSMutableDictionary *wdict=[[mainlistarr objectAtIndex:position]objectForKey:@"temp"];
        NSMutableString *minval=[wdict objectForKey:@"min"];
        int mval=[minval intValue]-273.15;
        NSMutableString *maxval=[wdict objectForKey:@"max"];
        int mxval=[maxval intValue]-273.15;
        warr=[[mainlistarr objectAtIndex:position]objectForKey:@"weather"];
        NSString *iconimgurl=[NSString stringWithFormat:@"http://openweathermap.org/img/w/%@.png",[[warr objectAtIndex:0]objectForKey:@"icon"]];
        NSString *estring=[[mainlistarr objectAtIndex:position]objectForKey:@"dt"];
        double eval=[estring doubleValue];
        NSDate *sdate=[NSDate dateWithTimeIntervalSince1970:eval];
        NSDateFormatter *dateformat=[NSDateFormatter new];
        [dateformat setDateStyle:NSDateFormatterMediumStyle];
    //Update on Specified Label
        wspeedlb.text=[[NSString stringWithFormat:@"%@",[[mainlistarr objectAtIndex:position]objectForKey:@"speed"]]stringByAppendingString:@"m/s"];
        tmin.text=[NSString stringWithFormat:@"%i%@%@",mval,@"\u00B0",@"C"];
        tmax.text=[NSString stringWithFormat:@"%i%@%@",mxval,@"\u00B0",@"C"];
        desclb.text=[NSString stringWithFormat:@"%@",[[warr objectAtIndex:0]objectForKey:@"description"]];
        subimgv.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:iconimgurl]]];
        preslb.text=[[NSString stringWithFormat:@"%@",[[mainlistarr objectAtIndex:position]objectForKey:@"pressure"]]stringByAppendingString:@"hpa"];
        datelb.text=[dateformat stringFromDate:sdate];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)backaction:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
