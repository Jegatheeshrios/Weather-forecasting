//
//  ViewController.m
//  WeatherTask
//
//  Created by Kandavel on 14/12/1937 SAKA.
//  Copyright © 1937 SAKA J. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    
    textalert=[[UIAlertView alloc]initWithTitle:@"Textbox Insruction!" message:@"Type the Single City or if More City then separte by Comma (,)" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        cellalert=[[UIAlertView alloc]initWithTitle:@"Select City Alert!" message:@"Select the Cityname and see the weather forcast" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    netalert=[[UIAlertView alloc]initWithTitle:@"Internet Alert!" message:@"Unable to Connect the Internet Check Wi-Fi Status" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    //Reachablity Class for Checking Network Connection
    reachclass=[Reachability reachabilityForInternetConnection];
    [textalert show];
    [maintext setDelegate:self];
       [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
-(IBAction)Submitaction:(id)sender
{
    textarr=[maintext.text componentsSeparatedByString:@","];
    mtextarr=[[NSMutableArray alloc]initWithArray:textarr];
    [maintableview setDataSource:self];
    [maintableview setDelegate:self];
    [maintext setClearButtonMode:UITextFieldViewModeAlways];
    [maintableview reloadData];
    [maintext resignFirstResponder];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [mtextarr count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[maintableview dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    cell.textLabel.text=[mtextarr objectAtIndex:indexPath.row];
    [cellalert show];
    return cell;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [maintext resignFirstResponder];
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIStoryboard *story1=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SViewController *viewobj=[story1 instantiateViewControllerWithIdentifier:@"Scrollview1"];
        viewobj.citystr=[mtextarr objectAtIndex:indexPath.row];
    NSInteger state=[reachclass currentReachabilityStatus];
    if(state==NotReachable)
    {
        [netalert show];
    }
    else if(state==ReachableViaWiFi || state==ReachableViaWWAN)
    {
        [self presentViewController:viewobj animated:YES completion:nil];
    }
    
}
-(BOOL)textFieldShouldClear:(UITextField *)textField
{
    [mtextarr removeAllObjects];
    [maintableview reloadData];
    return YES;
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [maintext resignFirstResponder];
    return YES;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated
{
    [maintableview beginUpdates];
     [maintableview endUpdates];
}
@end
