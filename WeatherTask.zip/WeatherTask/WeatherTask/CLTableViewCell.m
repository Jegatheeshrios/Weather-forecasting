//
//  CLTableViewCell.m
//  WeatherTask
//
//  Created by Kandavel on 14/12/1937 SAKA.
//  Copyright (c) 1937 SAKA J. All rights reserved.
//

#import "CLTableViewCell.h"

@implementation CLTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
