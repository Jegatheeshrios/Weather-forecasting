//
//  CCTableViewController.m
//  WeatherTask
//
//  Created by Kandavel on 14/12/1937 SAKA.
//  Copyright (c) 1937 SAKA J. All rights reserved.
//

#import "CCTableViewController.h"

@interface CCTableViewController ()

@end

@implementation CCTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    cmainstr=@"http://api.openweathermap.org/data/2.5/forecast/daily?q=Bangalore&cnt=14&APPID=9305c804f0a08b11207e6b25cf1ee59a";
    NSLog(@"%@",cmainstr);
    cmainurlstr=[NSURL URLWithString:cmainstr];
    cmrequest=[NSMutableURLRequest requestWithURL:cmainurlstr];
    [cmrequest setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [cmrequest setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [cmrequest setValue:[NSString stringWithFormat:@"%lu",[cmainstr length]] forHTTPHeaderField:@"Content-Lenght"];
    [cmrequest setHTTPMethod:@"POST"];
    [cmrequest setHTTPBody:[cmainstr dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLResponse *resp=nil;
    NSError *err1=nil;
    cmaindata=[NSURLConnection sendSynchronousRequest:cmrequest returningResponse:&resp error:&err1];
   // NSLog(@"%@",cmaindata);
    cmaindict=[NSJSONSerialization JSONObjectWithData:cmaindata options:kNilOptions error:nil];
    //NSLog(@"Main Json Data's%@",cmaindict);
    cityname1=[[cmaindict objectForKey:@"city"]objectForKey:@"name"];
    counname1=[[cmaindict objectForKey:@"city"]objectForKey:@"country"];
    citymainname=[cityname1 stringByAppendingString:counname1];
    clistarr=[cmaindict objectForKey:@"list"];
    NSLog(@"Main List%@",clistarr);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    // Return the number of rows in the section.
    return [clistarr count];
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return citymainname;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CCTableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    if(cell==nil)
    {
        cell=[[CCTableViewCell alloc]init];
    }

    cell.presslbl.text=[[NSString stringWithFormat:@"%@",[[clistarr objectAtIndex:indexPath.row]objectForKey:@"pressure"]]stringByAppendingString:@"hpa"];
    cell.wspeedlbl.text=[[NSString stringWithFormat:@"%@",[[clistarr objectAtIndex:indexPath.row]objectForKey:@"speed"]]stringByAppendingString:@"m/s"];
    cell.cloudlbl.text=[[NSString stringWithFormat:@"%@",[[clistarr objectAtIndex:indexPath.row]objectForKey:@"clouds"]]stringByAppendingString:@"%"];
    cell.rainlbl.text=[NSString stringWithFormat:@"%@",[[clistarr objectAtIndex:indexPath.row]objectForKey:@"rain"]];
    NSString *epochstr=[[clistarr objectAtIndex:indexPath.row]objectForKey:@"dt"];
    double epochform=[epochstr doubleValue];
    NSLog(@"%f",epochform);
    NSDate *cdate=[NSDate dateWithTimeIntervalSince1970:epochform];
    NSLog(@"%@",cdate);
    NSDateFormatter *dateformat=[NSDateFormatter new];
    [dateformat setDateStyle:NSDateFormatterMediumStyle];
    cell.datelbl.text=[dateformat stringFromDate:cdate];
    
                       if([cell.rainlbl.text isEqualToString:@"(null)"])
        cell.rainlbl.text=@"0";
    
   NSMutableArray *warr=[[clistarr objectAtIndex:indexPath.row]objectForKey:@"weather"];
    NSMutableDictionary *tempdict=[[clistarr objectAtIndex:indexPath.row]objectForKey:@"temp"];
    NSLog(@"%@",tempdict);
   
    
    
    NSMutableString *tmin=[tempdict objectForKey:@"min"];
    int value=[tmin intValue];
    int minval=value-273.15;
    cell.tempmin.text=[NSString stringWithFormat:@"%i%@%@",minval,@"\u00B0",@"C"];
    
    NSMutableString *tmax=[tempdict objectForKey:@"max"];
    int value1=[tmax intValue];
    int maxval=value1-273.15;
    cell.tempmax.text=[NSString stringWithFormat:@"%i%@%@",maxval,@"\u00B0",@"C"];
    
    cell.desclbl.text=[[warr objectAtIndex:0]objectForKey:@"description"];
    NSString *iconurl=[NSString stringWithFormat:@"http://openweathermap.org/img/w/%@.png",[[warr objectAtIndex:0]objectForKey:@"icon"]];
    NSLog(@"%@",iconurl);
    cell.descimg.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:iconurl]]];
    
    return cell;
    


    
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
