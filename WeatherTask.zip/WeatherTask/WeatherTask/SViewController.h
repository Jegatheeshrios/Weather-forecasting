//
//  SViewController.h
//  WeatherTask
//
//  Created by Kandavel on 15/12/1937 SAKA.
//  Copyright (c) 1937 SAKA J. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SViewController : UIViewController
{
    UIView *subview1;
    UILabel *tmin,*tmax,*datelb,*wspeedlb,*desclb,*templbl,*preslb;
    UIImageView *subimgv;
    UIImage *qimg;
    int xAxis;
    IBOutlet UIScrollView *sview;
    NSString *mainstr,*qdatestr,*qmin,*qmax,*qspeed,*qpress,*qdesc;
    NSURL *mainurlstr;
    NSMutableURLRequest *mrequest;
    NSData *maindata;
    NSDictionary *maindict;
    NSMutableArray *mainlistarr,*warr;
    NSMutableString *cityname,*counname;
   
}
@property (nonatomic,strong) NSString *citystr;
@property NSMutableDictionary *subdict;
@property(nonatomic,strong)IBOutlet UILabel *scityname;
-(IBAction)backaction:(id)sender;
-(void)updateInfo:(int)position;
@end
