//
//  CCTableViewController.h
//  WeatherTask
//
//  Created by Kandavel on 14/12/1937 SAKA.
//  Copyright (c) 1937 SAKA J. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CCTableViewCell.h"

@interface CCTableViewController : UITableViewController
{
    NSString *cmainstr,*citymainname;
    NSURL *cmainurlstr;
    NSMutableURLRequest *cmrequest;
    NSData *cmaindata;
    NSDictionary *cmaindict;
    NSMutableString *cityname1,*counname1;
    NSMutableArray *clistarr;
}
@end
